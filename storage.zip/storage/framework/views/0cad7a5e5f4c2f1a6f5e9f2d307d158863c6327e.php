<div class="sidebar-left">
    <header class="header" id="header">
        <div class="header_toggle"> <i class='bx bx-user' id="header-toggle"></i> </div>
    </header>
    <div class="l-navbar" id="nav-bar">
        <nav class="nav l-navbar-1 show">
            <div>
                <div class="nav_list">
                    <ul>
                        <li><a href="<?php echo e(route('doctor.dashboard')); ?>"
                                class="nav_link <?php echo e(Request::is('medical-stuff/dashboard') ? 'active' : ''); ?>"> <i
                                    class='bx bx-grid-alt nav_icon'></i>
                                <span class="nav_name">Dashboard</span> </a>
                        </li>
                        <li><a href="#"
                                class="nav_link sub-link <?php echo e(Request::is('medical-stuff/profile') || Request::is('medical-stuff/change-password') ? 'active' : ''); ?>">
                                <i class='bx bxs-user nav_icon'></i><span class="nav_name">Manage
                                    Account</span></a>
                            <ul class="sub-nav">
                                <li><a href="<?php echo e(route('doctor.profile')); ?>"
                                        class="nav_link <?php echo e(Request::is('medical-stuff/profile') ? 'sub-li-active' : ''); ?>">
                                        <i class='bx bxs-user'></i><span class="nav_name">My
                                            Profile</span> </a></li>
                                <li><a href="<?php echo e(route('doctor.change.password')); ?>"
                                        class="nav_link <?php echo e(Request::is('medical-stuff/change-password') ? 'sub-li-active' : ''); ?>">
                                        <i class='bx bxs-key'></i><span class="nav_name">Change
                                            Password</span> </a></li>
                                
                            </ul>
                        </li>
                        
                        <div class="sub-head">
                            <h4>CLINIC VISIT</h4>
                        </div>
                        <li> <a href="<?php echo e(route('doctor.booking-history')); ?>"
                                class="nav_link <?php echo e(Request::is('medical-stuff/booking-history') ? 'active' : ''); ?>"><i
                                    class='bx bxs-calendar nav_icon'></i> <span class="nav_name">Booking History</span>
                            </a></li>
                        <li>
                            <a href="<?php echo e(route('doctor.payment-history')); ?>" class="nav_link <?php echo e(Request::is('medical-stuff/payment-history/*') ? 'active' : ''); ?>"> <i
                                class='bx bx-notepad nav_icon'></i> <span class="nav_name">Payment
                                History</span> </a>
                        </li>
                        <li><a href="<?php echo e(route('doctor.notifications')); ?>"
                                class="nav_link <?php echo e(Request::is('medical-stuff/notifications') ? 'active' : ''); ?>"> <i
                                    class='bx bx-clipboard nav_icon'></i> <span class="nav_name">Notification</span>
                            </a></li>
                        <li><a href="<?php echo e(route('doctor.manage-clinic.index')); ?>"
                                class="nav_link <?php echo e(Request::is('medical-stuff/manage-clinic*') ? 'active' : ''); ?>"> <i
                                    class='bx bxs-map nav_icon'></i> <span class="nav_name">Manage
                                    Clinic Address</span> </a></li>
                        <li><a href="<?php echo e(route('doctor.settings')); ?>"
                                class="nav_link <?php echo e(Request::is('medical-stuff/settings') ? 'active' : ''); ?>">
                                <i class='bx bx-cog nav_icon'></i><span class="nav_name">Settings</span>
                            </a></li>
                        <li><a href="<?php echo e(route('doctor.logout')); ?>" class="nav_link">
                                <i class='bx bx-log-out nav_icon'></i><span class="nav_name">Logout</span>
                            </a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/doctor/partials/sidebar.blade.php ENDPATH**/ ?>