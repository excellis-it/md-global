<div class="row">
    <?php if(count($notifications) > 0): ?>
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xl-12">
        <div class="notice-p">
            <p><?php echo e(nl2br($notification->message)); ?> </p>
        </div>
        <div class="notice-date">
            <h4><?php echo e(date('d.m.y', strtotime($notification->created_at))); ?> | <?php echo e(date('H.i A', strtotime($notification->created_at))); ?></h4>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="pagi_1 justify-content-center">
        <nav aria-label="Page navigation example">
            <div class="">
                <?php echo e($notifications->render()); ?>

            </div>
        </nav>
    </div>
    <?php else: ?>
    <div class="col-xl-12">
        <div class="notice-p">
            <p>No Notification Found</p>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/doctor/partials/message.blade.php ENDPATH**/ ?>