<?php
    use App\Models\User;
    use App\Helpers\Helper;
?>
<?php if(isset($slot_times)): ?>
    <div class="cl-slot-wrap same-size">
        <div class="cl-slot-icon d-flex align-items-center">
            <i class="fa-solid fa-calendar-days"></i>
            <h3><?php echo e(date('D, d M', strtotime($slot_times['slot_date']))); ?></h3>
        </div>
        <div class="dt-slot">
            <div class="row row-cols-xxl-3 row-cols-lg-3 row-cols-md-2 row-cols-1">
                <?php $__currentLoopData = Helper::slotSlice($slot_times['id']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <div class="time-pick date-pick size-fix">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="appointment_time"
                                    value="<?php echo e($time); ?>" id="time_<?php echo e($key); ?>" <?php if(Helper::countSlotTimeAvailability($slot_times['clinic_detail_id'],$slot_times['slot_date'], $time) > 0): ?> disabled <?php endif; ?>>
                                <label class="form-check-label" for="time_<?php echo e($key); ?>">
                                    <h3><?php echo e($time); ?></h3>
                                    <p class="<?php if(Helper::countSlotTimeAvailability($slot_times['clinic_detail_id'],$slot_times['slot_date'], $time) > 0): ?> red-color <?php endif; ?>"><?php if(Helper::countSlotTimeAvailability($slot_times['clinic_detail_id'],$slot_times['slot_date'], $time) > 0): ?> Not Available <?php else: ?> Available <?php endif; ?></p>
                                </label>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/ajax-clinic-visit-slot-time.blade.php ENDPATH**/ ?>