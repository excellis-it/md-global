<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
   Medical Staff Notifications
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="sidebar-sec" id="body-pd">
        <div class="container-fluid">
            <div class="sidebar-wrap d-flex justify-content-between">
                <?php echo $__env->make('frontend.doctor.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Content -->
                <div class="sidebar-right height-100">
                    <div class="content">
                        <div class="my-app-div-wrap">
                            <div class="content-head-wrap d-flex justify-content-between align-items-center">
                                <div class="content-head mb-4">
                                    <h2>Manage Clinic Address</h2>
                                    <h3><a href="<?php echo e(route('doctor.dashboard')); ?>">Dashboard</a>  / Manage Clinic Address</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="clinical-consultation-wrap">
                                        <div class="add-address-wrap">
                                            <div class="add-address-form-box">
                                                <form action="<?php echo e(route('doctor.change.password.submit')); ?>" name="form"
                                                    id="submitForm" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="row g-3">
                                                        <div class="form-group col-lg-6 col-md-12">
                                                            <input type="password" class="form-control" id="current_password"
                                                                name="current_password" value=""
                                                                placeholder="Current Password" >
                                                            <?php if($errors->has('current_password')): ?>
                                                                <span
                                                                    class="text-danger"><?php echo e($errors->first('current_password')); ?></span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="row g-3">
                                                        <div class="form-group col-lg-6 col-md-12">
                                                            <input type="password" class="form-control" id="new_password"
                                                                name="new_password" value=""
                                                                placeholder="New Password" >
                                                            <?php if($errors->has('new_password')): ?>
                                                                <span
                                                                    class="text-danger"><?php echo e($errors->first('new_password')); ?></span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="row g-3">
                                                        <div class="form-group col-lg-6 col-md-12">
                                                            <input type="password" class="form-control" id="confirm_password"
                                                                name="confirm_password" value=""
                                                                placeholder="Confirm Password" >
                                                            <?php if($errors->has('confirm_password')): ?>
                                                                <span
                                                                    class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-xl-4 col-lg-4 col-12">
                                                            <div class="main-btn-p pt-4">
                                                                <input type="submit" value="SAVE" class="sub-btn">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/doctor/change-password.blade.php ENDPATH**/ ?>