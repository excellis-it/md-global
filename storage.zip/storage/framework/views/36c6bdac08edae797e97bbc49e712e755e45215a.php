<?php
    use App\Models\User;
    use App\Helpers\Helper;
?>
<?php if(isset($clinic_details)): ?>
    <div class="cl-slot-wrap same-size">
        <?php if($clinic_details->count() > 0): ?>
            <div class="cl-slot-icon d-flex align-items-center">
                <i class="fa-solid fa-house-chimney-medical"></i>
                <h3>Clinic Visit Slots</h3>
            </div>
            <div class="dt-slot">
                <div class="row row-cols-xxl-3 row-cols-lg-2 row-cols-1">
                    <?php $__currentLoopData = $clinic_details['clinic_slots']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="time-pick date-pick">
                                <div class="form-check">
                                    <input class="form-check-input appointment-date" type="radio"
                                        name="appointment_date" value="<?php echo e($slot['slot_date']); ?>" data-id="<?php echo e($slot['id']); ?>"
                                        id="slot_<?php echo e($slot['id']); ?>" <?php if(Helper::slotAvailable($slot['id']) == 0): ?> disabled <?php endif; ?>>
                                    <label class="form-check-label" for="slot_<?php echo e($slot['id']); ?>">
                                        <h3><?php echo e(date('D, d M', strtotime($slot['slot_date']))); ?></h3>
                                        <p class="<?php if(Helper::slotAvailable($slot['id']) == 0): ?> red-color <?php endif; ?>"><?php if(Helper::slotAvailable($slot['id']) > 0): ?><?php echo e(Helper::slotAvailable($slot['id'])); ?> slots available <?php else: ?> Not Available <?php endif; ?></p>
                                    </label>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            No appointment available
        <?php endif; ?>
    </div>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/ajax-clinic-visit.blade.php ENDPATH**/ ?>