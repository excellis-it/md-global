<?php
    use App\Helpers\Helper;
?>
<?php if(isset($accept)): ?>
    <div class="modal on-modal fade" id="Modal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="mdl-img">
                    <div class="find-doc-slide-img">
                        <?php if($doctor['profile_picture']): ?>
                            <img src="<?php echo e(Storage::url($doctor['profile_picture'])); ?>" alt="">
                        <?php else: ?>
                            <img src="<?php echo e(asset('frontend_assets/images/fd-2.png')); ?>" alt="">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($doctor['name']); ?></h5>
                </div>
                <div class="modal-body">
                    
                    <?php if(count(Helper::video_call_prices()) > 0): ?>
                        <?php $__currentLoopData = Helper::video_call_prices(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $video_call_price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-12">
                                <input type="radio" name="telehealth_plan" id="tele-<?php echo e($key); ?>" value="<?php echo e($video_call_price['id']); ?>" class="video-call-price d-none" <?php echo e($key == 0 ? 'checked' : ''); ?>>
                                <label for="tele-<?php echo e($key); ?>" class="w-100">
                                    <div class="telehealth_plan">
                                        <span><?php echo e($video_call_price['title']); ?></span>
                                        <h5><?php echo e($video_call_price['price'] > 0 ? '$' . $video_call_price['price'] : 'Free'); ?>

                                            /
                                            <?php echo e($video_call_price['duration'] ? $video_call_price['duration'] . ' Min' : 'Free'); ?>

                                        </h5>
                                    </div>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-xl-12">
                            <div class="d-flex justify-content-center align-items-center">
                                <h5>No Telehealth Plan Available</h5>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="mdl-btn">
                        <a href="javascript:void(0)" id="payment_now" class="pay-now"
                            data-receiverid="<?php echo e(Auth::user()->id); ?>" data-id="<?php echo e($videocall_id); ?>"><span>Pay &
                                continue</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/includes/accept-zoom-request-modal.blade.php ENDPATH**/ ?>