<div class="booking-history-table">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th><span><i class="fa-regular fa-clock"></i></span>Appointment
                        time</th>
                    <th><span><i class="fa-regular fa-clock"></i></span>Duration
                    </th>
                    <th><span><i class="fa-solid fa-calendar-days"></i></span>Appointment
                        Date</th>
                    <th><span><i class="fa-solid fa-house-chimney-medical"></i></span>Clinic
                        Details</th>
                    <th>status</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($bookingHistory) > 0): ?>
                    <?php $__currentLoopData = $bookingHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="profile-div profile-div-2 profile-div-3 d-flex align-items-center">
                                    <div class="profile-img">
                                        <?php if($booking->user->profile_picture): ?>
                                            <img src="<?php echo e(Storage::url($booking->user->profile_picture)); ?>"
                                                alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend_assets/images/profile.png')); ?>" alt="">
                                        <?php endif; ?>
                                    </div>
                                    <div class="profile-text">
                                        <h2><?php echo e($booking->user->name); ?></h2>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($booking['appointment_time']); ?></td>
                            <td>30min</td>
                            <td><?php echo e(date('D, d M Y', strtotime($booking['appointment_date']))); ?></td>
                            <td><?php echo e($booking['clinic_name']); ?>

                                <?php echo e($booking['clinic_address']); ?></td>
                            <td
                                class="<?php if($booking['appointment_status'] == 'Done'): ?> status-1 <?php elseif($booking['appointment_status'] == 'Pending'): ?> status-2 <?php else: ?> status-3 <?php endif; ?>">
                                <?php echo e($booking['appointment_status']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No Booking History Found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="pagi_1 justify-content-center">
            <nav aria-label="Page navigation example">
                <?php if(method_exists($bookingHistory, 'links')): ?>
                    <?php if(count($bookingHistory) > 0): ?>
                        <div class="">
                            <?php echo e($bookingHistory->links()); ?>


                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/doctor/ajax-booking-history.blade.php ENDPATH**/ ?>