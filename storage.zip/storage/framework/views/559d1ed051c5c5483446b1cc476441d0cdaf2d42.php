<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        use App\Helpers\Helper;
    ?>
    <div class="login_sec_wrap">
        <div class="container-fluid login_container_fluid">
            <div class="row m-0 justify-content-end">
                <div class="col-xl-6 col-lg-12 col-12 p-0">
                    <div class="login_sec_left">
                        <div class="login_sec_left_bg"></div>
                        <div class="width_545">
                            <div class="main_hh">
                                <div class="login_sec_right_text">
                                    <div class="login-logo">
                                        <?php if(Helper::getLogo() != null): ?>
                                            <a href="<?php echo e(route('home')); ?>"><img
                                                    src="<?php echo e(Storage::url(Helper::getLogo())); ?>" /></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('home')); ?>"><img
                                                    src="<?php echo e(asset('frontend_assets/images/logo.png')); ?>" /></a>
                                        <?php endif; ?>

                                    </div>
                                    <div class="login-logo-head">
                                        <h1>Login to explore more</h1>
                                        <p>
                                            Log in to access your account and explore personalized features.
                                        </p>
                                    </div>
                                </div>
                                <div class="login_form">
                                    <form class="" action="<?php echo e(route('login.check')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="type" value="login_page">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1" class="form-label">Email ID</label>
                                            <input type="text" class="form-control" id="exampleInputEmail1"
                                                aria-describedby="emailHelp" value="<?php echo e(old('email')); ?>" name="email" />
                                            <?php if($errors->has('email')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                         
                                         

                                        <div class="form-group">
                                            <label for="txtPassword">Password</label>
                                            <div class="position-relative">
                                                <input type="password" id="password-field" class="form-control"
                                                    name="password" />
                                                <button type="button" id="btnToggle" class="toggle">
                                                    <i id="eyeIcon" toggle="#password-field"
                                                        class="fa fa-eye-slash toggle"></i>
                                                </button>
                                            </div>
                                            <?php if($errors->has('password')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                            <div class="login-text text-right">
                                                <p>
                                                    <a href="<?php echo e(route('forget.password')); ?>">Forgot Password?</a>
                                                </p>
                                            </div>
                                        </div>

                                        <button class="btn btn-lg btn-primary btn-block btn-login">
                                            LOGIN
                                        </button>
                                        <div class="login-text login-text-2 text-center">
                                            <p>
                                                Don’t Have an Account? <a href="<?php echo e(route('register')); ?>">Register NOW</a>
                                            </p>
                                        </div>
                                        <div class="login-text login-text-2 text-center">
                                            <p>
                                                Are you a medical stuff looking to log in? <a href="<?php echo e(route('medical-stuff.login')); ?>">Login NOW</a>
                                            </p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $("#eyeIcon").click(function() {
            // alert('d')
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/auth/login.blade.php ENDPATH**/ ?>