<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
   Medical Staff Profile
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="sidebar-sec" id="body-pd">
        <div class="container-fluid">
            <div class="sidebar-wrap d-flex justify-content-between">
                <?php echo $__env->make('frontend.doctor.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Content -->
                <div class="sidebar-right height-100">
                    <div class="content">
                        <div class="my-app-div-wrap">
                            <div class="content-head">
                                <h2>My Profile</h2>
                            </div>
                            <div class="my-profile-div">
                                <form action="<?php echo e(route('doctor.profile.update')); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-xl-2">
                                        <div class="profile-img">
                                            <?php if(Auth::user()->profile_picture): ?>
                                                <img src="<?php echo e(Storage::url(Auth::user()->profile_picture)); ?>" alt=""
                                                    id="blah">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('frontend_assets/images/profile.png')); ?>" alt=""
                                                    id="blah">
                                            <?php endif; ?>
                                            <div class="pro-cam-img-1">
                                                <label for="file-input">
                                                    <img src="<?php echo e(asset('frontend_assets/images/cam-img.png')); ?>" />
                                                </label>
                                                <input id="file-input" type="file" name="profile_picture"
                                                    onchange="readURL(this);" />
                                                <?php if($errors->has('profile_picture')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('profile_picture')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-10">
                                        <div class="profile-form">

                                            <div class="row">
                                                <div class="form-group col-lg-6 col-md-12">
                                                    <label>Name</label>
                                                    <input type="text" class="form-control" id=""
                                                        value="<?php echo e(Auth::user()->name); ?>" name="name" placeholder="Name">
                                                    <?php if($errors->has('name')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-lg-6 col-md-12">
                                                    <label>Phone Number</label>
                                                    <input type="text" class="form-control" id=""
                                                        value="<?php echo e(Auth::user()->phone); ?>" name="phone"
                                                        placeholder="Phone Number">
                                                    <?php if($errors->has('phone')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-lg-6 col-md-12">
                                                    <label>Email ID</label>
                                                    <input type="text" class="form-control" id="" readonly
                                                        value="<?php echo e(Auth::user()->email); ?>" name="email"
                                                        placeholder="Email ID">
                                                    <?php if($errors->has('email')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-lg-6 col-md-12">
                                                    <label>Date of Birth</label>
                                                    <input type="date" class="form-control" id=""
                                                        value="<?php echo e(Auth::user()->age); ?>" name="age" placeholder="Age"
                                                        max="<?php echo e(date('Y-m-d')); ?>">
                                                    <?php if($errors->has('age')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('age')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="row check-box m-0 p-0">
                                                    <div class="form-group col-md-6">
                                                        <label>Gender</label>
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input" type="radio" name="gender"
                                                                value="Male" id="inlineRadio1" value="option1"
                                                                <?php if(Auth::user()->gender == 'Male'): ?> checked <?php endif; ?>>
                                                            <label class="form-check-label" for="inlineRadio1">Male</label>
                                                        </div>
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input" type="radio" name="gender"
                                                                value="Female" id="inlineRadio2" value="option2"
                                                                <?php if(Auth::user()->gender == 'Female'): ?> checked <?php endif; ?>>
                                                            <label class="form-check-label"
                                                                for="inlineRadio2">Female</label>
                                                        </div>
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input" type="radio" name="gender"
                                                                value="Other" id="inlineRadio3" value="option2"
                                                                <?php if(Auth::user()->gender == 'Other'): ?> checked <?php endif; ?>>
                                                            <label class="form-check-label" for="inlineRadio3">Other</label>
                                                        </div>
                                                        <?php if($errors->has('gender')): ?>
                                                            <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="form-group  col-md-6">
                                                        <label>Specialization</label>
                                                        <select name="specialization_id[]" id="specialization_id"
                                                            class="form-control" multiple>
                                                            <option value="">Select Specialization</option>
                                                            <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($specialization['id']); ?>"
                                                                    <?php if(Auth::user()->doctorSpecializations->count() > 0): ?> <?php $__currentLoopData = Auth::user()->doctorSpecializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($item['specialization_id'] == $specialization['id']): ?> selected <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>>
                                                            <?php echo e($specialization['name']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php if($errors->has('specialization_id')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('specialization_id')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label>License Number</label>
                                                        <input type="text" class="form-control" id=""
                                                            value="<?php echo e(Auth::user()->license_number); ?>"
                                                            name="license_number" placeholder="License Number">
                                                        <?php if($errors->has('license_number')): ?>
                                                            <span
                                                                class="text-danger"><?php echo e($errors->first('license_number')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                    <div class="form-group col-md-6">
                                                        <label>Years of Experience (Years)</label>
                                                        <input type="text" class="form-control" id=""
                                                            value="<?php echo e(Auth::user()->year_of_experience); ?>"
                                                            name="years_of_experience" placeholder="Years of Experience">
                                                        <?php if($errors->has('years_of_experience')): ?>
                                                            <span
                                                                class="text-danger"><?php echo e($errors->first('years_of_experience')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                    <div class="form-group col-md-6">
                                                        <label>Address</label>
                                                        <input type="text" class="form-control" id=""
                                                            value="<?php echo e(Auth::user()->location); ?>" name="address"
                                                            placeholder="Address">
                                                        <?php if($errors->has('address')): ?>
                                                            <span
                                                                class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                                        <?php endif; ?>
                                                    </div>

                                                    
                                                    <div class="form-group col-md-6">
                                                        <label>Education</label>
                                                        <input type="text" class="form-control" id=""
                                                            value="<?php echo e(Auth::user()->education); ?>" name="education"
                                                            placeholder="Education">
                                                        <?php if($errors->has('education')): ?>
                                                            <span
                                                                class="text-danger"><?php echo e($errors->first('education')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                    <div class="form-group col-md-12">
                                                        <label>About Yourself</label>
                                                        <textarea class="form-control" id="" name="about_yourself"
                                                            placeholder="About Yourself"><?php echo e(Auth::user()->about_yourself); ?></textarea>
                                                        <?php if($errors->has('about_yourself')): ?>
                                                            <span
                                                                class="text-danger"><?php echo e($errors->first('about_yourself')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                                <div class="col-xl-5">
                                                    <div class="main-btn-p pt-4">
                                                        <input type="submit" value="SAVE" class="sub-btn">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <script>
        $(document).ready(function() {
            $('#specialization_id').select2();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/doctor/profile.blade.php ENDPATH**/ ?>