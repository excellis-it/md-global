<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Booking Appointment and Video Consultancy
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        use App\Models\User;
        use App\Helpers\Helper;
    ?>
    
    <section id="loading">
        <div id="loading-content"></div>
    </section>
    <section class="inr-bnr">
        <div class="inr-bnr-img">
            <img src="<?php echo e(asset('frontend_assets/images/tele-bg.jpg')); ?>" alt="" />
            <div class="inr-bnr-text">
                <h1>Booking Appointment and Video Consultancy</h1>
            </div>
        </div>
    </section>
    <section class="clinic-sec">
        <div class="container">
            <div class="clinic-sec-wrap">
                <div class="row justify-content-center">
                    <div class="col-xl-9">
                        <div class="cl-dc-bx">
                            <div class="row justify-content-between">
                                <div class="col-xl-3 col-lg-3 col-md-12 col-12">
                                    <div class="find-doc-slide-img" id="<?php echo e($doctor['id']); ?>-status">
                                        <?php if($doctor['profile_picture']): ?>
                                            <img src="<?php echo e(Storage::url($doctor['profile_picture'])); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend_assets/images/profile.png')); ?>" alt="">
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-12 col-12">
                                    <div class="find-doc-slide-text">
                                        <h3><?php echo e($doctor['name']); ?></h3>
                                        <h4><?php echo e(User::getDoctorSpecializations($doctor['id'])); ?></h4>
                                        <h4>
                                            <?php if($doctor['license_number']): ?>
                                                License No. <?php echo e($doctor['license_number']); ?>

                                            <?php endif; ?>
                                        </h4>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-12 col-12">
                                    <div class="pec-div">
                                        <span class="pec d-block"><i class="fa-solid fa-thumbs-up"></i>99%</span>
                                        <span class="exp d-block"><i class="fa-regular fa-period"></i>
                                            <?php echo e($doctor['year_of_experience']); ?> Years
                                            Exp</span>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-12 col-12">
                                    <div class="find-doc-slide-text">
                                        <h5><?php echo e($doctor['location']); ?></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="slot-sec">
        <div class="container">
            <div class="slot-sec-wrap">
                <div class="row justify-content-center">
                    <div class="col-xl-8">
                        <div class="slot-div">
                            <div class="row">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="chat-sec chat-slot" id="chat-view">
        <?php echo $__env->make('frontend.chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <?php if($clinics->count() > 0): ?>
        <section class="cl-tm-slot booking-slot">
            <form action="<?php echo e(route('appointment-store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="doctor_id" value="<?php echo e($doctor['id']); ?>">
                <div class="container">
                    <div class="cl-name-div">
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="cl-slot-wrap">
                                    <div class="cl-slot-icon d-flex align-items-center">
                                        <i class="fa-solid fa-house-chimney-medical"></i>
                                        <h3>Clinic Name</h3>
                                    </div>
                                    <div class="clinic-name-ck-div">
                                        <div class="clinic-name-ck">

                                            <div class="row align-items-center justify-content-between">
                                                
                                                <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div
                                                        class="col-xl-5 col-12 <?php if(Helper::countSlotAvailability($clinic['id']) == 0): ?> disable-or-not <?php endif; ?>">
                                                        <label for="clinic_name_<?php echo e($clinic['id']); ?>"
                                                            style="cursor: pointer;" class="form-check d-flex">
                                                            <div class="form-check-box">
                                                                <input class="form-check-input clinic_add" type="radio"
                                                                    value="<?php echo e($clinic['id']); ?>" name="clinic_id"
                                                                    id="clinic_name_<?php echo e($clinic['id']); ?>"
                                                                    <?php if(Helper::countSlotAvailability($clinic['id']) == 0): ?> disabled <?php endif; ?>>
                                                            </div>
                                                            <div class="form-text">
                                                                <h3><?php echo e($clinic['clinic_name']); ?> </h3>
                                                                <p><?php echo e($clinic['clinic_address']); ?></p>
                                                            </div>
                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="cl-tm-slot-wrap">
                        <div class="row justify-content-center align-items-center">
                            <div class="col-xl-6 col-md-12" id="clinic_visit_slots">
                                <?php echo $__env->make('frontend.ajax-clinic-visit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="col-xl-6 col-md-12" id="clinic_visit_slots_time">
                                <?php echo $__env->make('frontend.ajax-clinic-visit-slot-time', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            </div>
                        </div>
                        <div class="row justify-content-center align-items-center">
                            <div class="col-xl-4 col-md-6 col-12">
                                <div class="main-btn-p pt-4">
                                    <input type="submit" value="Book" class="sub-btn">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </section>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $("#payment_now").click(function() {
                $("#Modal1").modal('hide');
                $("#Modal2").modal('show');
            });

            $("#Modal1").modal('show');
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.chat-slot').css('display', 'none');
            $('.clinic-visit').on('click', function() {
                $('.chat').removeClass('active-slot');
                $(this).addClass('active-slot');
                $('.booking-slot').css('display', 'block');
                $('.chat-slot').css('display', 'none');
            });
            $('#show-chat').on('click', function() {
                var doctor_id = "<?php echo e($doctor['id']); ?>"
                $('#loading').addClass('loading');
                $('#loading-content').addClass('loading-content');
                $.ajax({
                    url: "<?php echo e(route('doctor.chat')); ?>",
                    type: 'GET',
                    data: {
                        doctor_id: doctor_id,
                    },
                    success: function(resp) {
                        // console.log(resp);
                        if (resp.status == true) {
                            $('.booking-slot').css('display', 'none');
                            $('.clinic-visit').removeClass('active-slot');
                            $('#show-chat').addClass('active-slot');
                            $('.chat-slot').css('display', 'block');
                            $('.chat-slot').html(resp.view);
                            if (resp.chat_count > 0) {
                                scrollChatToBottom()
                            }
                            $('#loading').removeClass('loading');
                            $('#loading-content').removeClass('loading-content');
                        } else {
                            // console.log(resp);
                            toastr.error(resp.message);
                            $('#loading').removeClass('loading');
                            $('#loading-content').removeClass('loading-content');
                        }
                    }
                });
            });

            function scrollChatToBottom() {
                var messages = document.getElementById('chat-container');
                messages.scrollTop = messages.scrollHeight;
            }
        });
    </script>


    <script>
        $('.clinic_add').on('change', function() {
            var clinic_id = $(this).val();
            $('#loading').addClass('loading');
            $('#loading-content').addClass('loading-content');
            $.ajax({
                url: "<?php echo e(route('clinic.visit.slot-ajax')); ?>",
                type: 'GET',
                data: {
                    clinic_id: clinic_id
                },
                success: function(resp) {
                    // console.log(resp.clinic.slots);

                    $('#clinic_visit_slots').html(resp.view)
                    $('#loading').removeClass('loading');
                    $('#loading-content').removeClass('loading-content');
                }
            });
        });
    </script>

    <script>
        $(document).on("change", ".appointment-date", function() {
            var slot_id = $(this).data('id');
            $('#loading').addClass('loading');
            $('#loading-content').addClass('loading-content');
            // alert(slot_id)
            $.ajax({
                url: "<?php echo e(route('clinic.ajax-clinic-visit-slot-time')); ?>",
                type: 'GET',
                data: {
                    slot_id: slot_id
                },
                success: function(resp) {
                    // console.log(resp.clinic.slots);

                    $('#clinic_visit_slots_time').html(resp.view)
                    $('#loading').removeClass('loading');
                    $('#loading-content').removeClass('loading-content');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/booking-and-consultancy.blade.php ENDPATH**/ ?>