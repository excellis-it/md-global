<?php $__env->startSection('title'); ?>
    Dashboard - <?php echo e(env('APP_NAME')); ?> admin
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <div class="content container-fluid">

            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <h3 class="page-title">Welcome Admin!</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row card_dash">
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                    <a href="<?php echo e(route('patients.index')); ?>" style="color: black">
                        <div class="card dash-widget">
                            <div class="card-body">
                                <span class="dash-widget-icon"><i class="fa fa-wheelchair"></i></span>
                                <div class="dash-widget-info">
                                    <h3><?php echo e($count['patient']); ?></h3>
                                    <span>Total Patient</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                    <a href="<?php echo e(route('doctors.index')); ?>" style="color: black">
                        <div class="card dash-widget">
                            <div class="card-body">
                                <span class="dash-widget-icon"><i class="fas fa-user-md"></i></span>
                                <div class="dash-widget-info">
                                    <h3><?php echo e($count['doctor']); ?></h3>
                                    <span>TotalMedical Staff</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                    <a href="<?php echo e(route('appointments.index')); ?>" style="color: black">
                        <div class="card dash-widget">
                            <div class="card-body">
                                <span class="dash-widget-icon"><i class="fa fa-calendar"></i></span>
                                <div class="dash-widget-info">
                                    <h3><?php echo e($count['total_appointment']); ?></h3>
                                    <span>Total Appointments</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                    <a href="<?php echo e(route('membership-history.index')); ?>" style="color: black">
                        <div class="card dash-widget">
                            <div class="card-body">
                                <span class="dash-widget-icon"><i class="fa fa-usd"></i></span>
                                <div class="dash-widget-info">
                                    <h3>$<?php echo e($count['membership_total_payment']); ?></h3>
                                    <span>Membership Transaction</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                    <a href="<?php echo e(route('clinics.index')); ?>" style="color: black">
                        <div class="card dash-widget">
                            <div class="card-body">
                                <span class="dash-widget-icon"><i class="fas fa-clinic-medical"></i></span>
                                <div class="dash-widget-info">
                                    <h3><?php echo e($count['clinics']); ?></h3>
                                    <span>Total Clinics</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                    <a href="<?php echo e(route('blogs.index')); ?>" style="color: black">
                        <div class="card dash-widget">
                            <div class="card-body">
                                <span class="dash-widget-icon"><i class="fas fa-blog"></i></span>
                                <div class="dash-widget-info">
                                    <h3><?php echo e($count['blogs']); ?></h3>
                                    <span>Total Blogs</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                    <a href="<?php echo e(route('specializations.index')); ?>" style="color: black">
                        <div class="card dash-widget">
                            <div class="card-body">
                                <span class="dash-widget-icon"><i class="fa fa-heart"></i></span>
                                <div class="dash-widget-info">
                                    <h3><?php echo e($count['specializations']); ?></h3>
                                    <span>Total Specialization</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                    <a href="<?php echo e(route('symptoms.index')); ?>" style="color: black">
                        <div class="card dash-widget">
                            <div class="card-body">
                                <span class="dash-widget-icon"><i class="fa fa-stethoscope"></i></span>
                                <div class="dash-widget-info">
                                    <h3><?php echo e($count['symptoms']); ?></h3>
                                    <span>Total Symptoms</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-lg-12 col-xl-6 d-flex">
                    <div class="card flex-fill dash-statistics">
                        <div class="card-body">
                            <h5 class="card-title">Membership Purchase Transaction</h5>
                            <?php
                                $year = 2022;
                            ?>
                            <div>
                                <select name="" id="year" class="form-control">
                                    <?php for($i = $year; $i <= date('Y'); $i++): ?>
                                        <option value="<?php echo e($year); ?>"
                                            <?php if($year == date('Y')): ?> selected="" <?php endif; ?>>
                                            <?php echo e($year); ?></option>
                                        <?php $year++ ?>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div id="membership-bar-chart">
                                <?php echo $__env->make('admin.membership-bar-chart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-12 col-xl-6 d-flex">
                    <div class="card flex-fill">
                        <div class="card-body">
                            <h4 class="card-title">Top 5 Clinics appointment</h4>
                            <div class="statistics">
                                <div class="row">
                                    <div class="col-md-6 col-6 text-center">
                                        <div class="stats-box mb-4">
                                            <p>Total Clinics</p>
                                            <h3><?php echo e($count['clinics']); ?></h3>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6 text-center">
                                        <div class="stats-box mb-4">
                                            <p>Appointments</p>
                                            <h3><?php echo e($count['total_appointment']); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="progress mb-4">
                                <?php $__currentLoopData = $top_5_clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php
                                    $percentage = ($item->total_appointment / $count['total_appointment']) * 100;
                                    // round to 2 decimal places
                                    $percentage = round($percentage, 0);
                                ?>
                                    <div class="progress-bar  <?php if($key == 0): ?> bg-primary
                                <?php elseif($key == 1): ?>
                                    bg-warning
                                <?php elseif($key == 2): ?>
                                    bg-success
                                <?php elseif($key == 3): ?>
                                    bg-danger
                                <?php elseif($key == 4): ?>
                                    bg-info <?php endif; ?>"
                                        role="progressbar" style="width: <?php echo e($percentage); ?>%" aria-valuenow="<?php echo e($percentage); ?>" aria-valuemin="0"
                                        aria-valuemax="100"><?php echo e($percentage); ?>%</div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div>
                                <?php $__currentLoopData = $top_5_clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><i
                                            class="fa fa-dot-circle-o
                                        
                                        <?php if($key == 0): ?> text-primary
                                        <?php elseif($key == 1): ?>
                                            text-warning
                                        <?php elseif($key == 2): ?>
                                            text-success
                                        <?php elseif($key == 3): ?>
                                            text-danger
                                        <?php elseif($key == 4): ?>
                                            text-info <?php endif; ?>
                                        me-2"></i><?php echo e($item->clinic_name); ?>

                                        <span class="float-end"><?php echo e($item->total_appointment); ?></span>
                                    </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#year').change(function() {
                var year = $(this).val();
                $.ajax({
                    url: "<?php echo e(route('admin.membership.bar.chart')); ?>",
                    type: "GET",
                    data: {
                        year: year
                    },
                    success: function(resp) {
                        $('#membership-bar-chart').html(resp.view);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>