<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
   Medical Staff Payment History
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="sidebar-sec" id="body-pd">
        <div class="container-fluid">
            <div class="sidebar-wrap d-flex justify-content-between">
                <?php echo $__env->make('frontend.doctor.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Content -->
                <div class="sidebar-right height-100">
                    <div class="content">
                        <div class="my-app-div-wrap">
                            <div class="content-head">
                                <h2>Payment History</h2>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="clinical-consultation-wrap d-payment">
                                        <div class="clinicl-head clinicl-head-l">
                                            <h3>Video Consultation</h3>
                                        </div>
                                        <div class="chat-box-1-wrap">
                                            <div class="row">
                                                <?php if(count($payment_history) > 0): ?>
                                                    <?php $__currentLoopData = $payment_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-xl-4 col-6 col-12">
                                                            <div class="chat-box-1-1">
                                                                <div
                                                                    class="chat-box-1 d-flex align-items-center justify-content-between">
                                                                    <div
                                                                        class="profile-div profile-div-2 d-flex align-items-center">
                                                                        <div class="profile-img">
                                                                            <?php if($payment['patient']['profile_picture']): ?>
                                                                                <img src="<?php echo e(Storage::url($payment['patient']['profile_picture'])); ?>"
                                                                                    alt="">
                                                                            <?php else: ?>
                                                                                <img src="<?php echo e(asset('frontend_assets/images/fd-2.png')); ?>"
                                                                                    alt="">
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div class="profile-text">
                                                                            <h2><?php echo e($payment['patient']['name']); ?></h2>
                                                                            <h3><?php echo e(date('D, d M Y H:i A', strtotime($payment['created_at']))); ?>

                                                                                </h3>
                                                                        </div>
                                                                    </div>
                                                                    <div class="cam-img">
                                                                        <span><i class="fa-solid fa-video"></i></span>
                                                                    </div>
                                                                </div>
                                                                <div>
                                                                    <div class="for-vdo">
                                                                        <h3><?php echo e($payment['call_duration']); ?> Min Video Call Duration</h3>
                                                                          <h3>  <span>$<?php echo e($payment['amount']); ?></span> Payment via stripe</h3>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <div class="pagi_1 justify-content-center">
                                                        <nav aria-label="Page navigation example">
                                                            <div class="">
                                                                <?php echo e($payment_history->render()); ?>

                                                            </div>
                                                        </nav>
                                                    </div>
                                                <?php else: ?>
                                                
                                                <div class="col-12" style="text-align: center">
                                                    <h5>!! No payment history found</h5>
                                                </div>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/doctor/payment-history.blade.php ENDPATH**/ ?>