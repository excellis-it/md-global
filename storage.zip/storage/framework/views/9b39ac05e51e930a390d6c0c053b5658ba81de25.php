<?php $__env->startSection('meta_title'); ?>
<meta name="keywords" content="<?php echo e($telehealth['meta_keyword'] ?? ''); ?>">
<meta name="description" content="<?php echo e($telehealth['meta_description'] ?? ''); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e($telehealth['meta_title'] ?? ''); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
use App\Helpers\Helper;
$getTelehealth = Helper::getTelehealth();
?>
<section class="inr-bnr">
    <div class="inr-bnr-img">
        <div class="inr-bnr-text">
            <h1>Telehealth</h1>
            <nav>
                <ol class="cd-breadcrumb custom-separator">
                    <li><a href="">Home</a></li>
                    <li class="current"><em>Telehealth</em></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<?php if(count($symptoms) > 0): ?>
<section class="feeling-sec">
    <div class="container">
        <div class="feeling-sec-wrap">
            <div class="head-1 h-b text-center">
                <h2><?php echo $getTelehealth['symptom_title']; ?></h2>
                <p><b><?php echo $getTelehealth['symptom_description']; ?></b></p>
            </div>

            <div class="feel-slide">
                <?php $__currentLoopData = $symptoms->chunk(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="feel-slide-wrap">
                    <div class="row row-cols-xxl-6 row-cols-lg-4 row-cols-md-2 row-cols-1">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="feel-box">
                                <a href="<?php echo e(route('doctors', ['type' => 'symptoms', 'slug' => $symptom['symptom_slug']])); ?>">
                                    <div class="feel-icon-div">
                                        <div class="feel-icon-box-1 feel-icon">
                                            <img src="<?php echo e(Storage::url($symptom['symptom_image'])); ?>" alt="">
                                        </div>
                                    </div>
                                    <div class="feel-text">
                                        <h4>
                                            <?php echo e($symptom['symptom_name']); ?>

                                        </h4>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- <div class="doc-ct-sec">
                    <div class="doc-ct-sec-wrap">
                        <div class="row justify-content-center align-items-center">
                            <div class="col-xl-4 col-md-6 col-12">
                                <div class="doc-img">
                                    <a href="#">
                                        <?php if($getTelehealth['offer_image_1'] != null): ?>
                                            <img src="<?php echo e(Storage::url($getTelehealth['offer_image_1'])); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend_assets/images/doc-1.png')); ?>" alt="">
                                        <?php endif; ?>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12">
                                <div class="doc-img">
                                    <a href="#">
                                         <?php if($getTelehealth['offer_image_2'] != null): ?>
                                            <img src="<?php echo e(Storage::url($getTelehealth['offer_image_2'])); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend_assets/images/doc-2.png')); ?>" alt="">
                                         <?php endif; ?>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12">
                                <div class="doc-img">
                                    <a href="#">
                                        <?php if($getTelehealth['offer_image_3'] != null): ?>
                                            <img src="<?php echo e(Storage::url($getTelehealth['offer_image_3'])); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend_assets/images/doc-3.png')); ?>" alt="">
                                        <?php endif; ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->
    </div>
</section>
<?php endif; ?>
<?php if(count($speciliaztions) > 0): ?>
<section class="bk-app-sec bg-white">
    <div class="container">
        <div class="bk-app-sec-wrap">
            <div class="row justify-content-between">
                <div class="col-xl-9 col-12">
                    <div class="head-1 h-b">
                        <h2><?php echo $getTelehealth['specialization_title']; ?></h2>
                    </div>
                </div>
                <div class="col-xl-3 col-12">
                    <div class="main-btn">
                        <a href="<?php echo e(route('all-specializations')); ?>" tabindex="0"><span>View all
                                Specialization</span><span class="btn-arw"><i class="fa-solid fa-arrow-right"></i></span></a>
                    </div>
                </div>
            </div>
            <div class="app-doc-wrap">
                <?php $__currentLoopData = $speciliaztions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciliaztion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="app-doc-box">
                    <a href="<?php echo e(route('doctors', ['type' => 'speciaization', 'slug' => $speciliaztion['slug']])); ?>">
                        <div class="app-doc-img">
                            <img src="<?php echo e(Storage::url($speciliaztion['image'])); ?>" alt="">
                        </div>
                    </a>
                    <div class="app-doc-text">
                        <a href="<?php echo e(route('doctors', ['type' => 'speciaization', 'slug' => $speciliaztion['slug']])); ?>">
                            <h3><?php echo e($speciliaztion['name']); ?></h3>
                        </a>
                        <p><?php echo e(substr($speciliaztion['description'], 0, 80)); ?>

                        </p>
                    </div>
                    <?php if($speciliaztion['doctor_count'] > 0): ?>
                    <div class="doc-avl d-flex">
                        <div class="doc-avl-img">
                            <img src="<?php echo e(asset('frontend_assets/images/doc-v.png')); ?>" alt="">
                        </div>
                        <div class="doc-avl-text">
                            <h4><?php echo e($speciliaztion['doctor_count']); ?>Medical Stuff available</h4>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="doc-avl d-flex">
                        <div class="doc-avl-img">
                            <img src="<?php echo e(asset('frontend_assets/images/doc-v.png')); ?>" alt="">
                        </div>
                        <div class="doc-avl-text">
                            <h4>Medical Stuff not available</h4>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="hw-wrks">
    <div class="container">
        <div class="hw-wrks-wrap">
            <div class="head-1 h-b text-center">
                <h2>How it works</h2>
            </div>
            <div class="wrk-div">
                <!-- <div class="wrk-div-bg">
                                         <img src="<?php echo e(asset('frontend_assets/images/wv.png')); ?>" alt="">
                                      </div> -->
                <div class="row justify-content-center">
                    <div class="col-xl-3 col-md-12 col-12">
                        <div class="wrk-div-box">
                            <div class="wrk-icon">
                                <?php if($getTelehealth['how_it_works_icon_1_image'] != null): ?>
                                <img src="<?php echo e(Storage::url($getTelehealth['how_it_works_icon_1_image'])); ?>" alt="<?php echo e($getTelehealth['how_it_works_icon_1_title']); ?>">
                                <?php else: ?>
                                <img src="<?php echo e(asset('frontend_assets/images/w-1.png')); ?>">
                                <?php endif; ?>

                            </div>
                            <div class="wrk-icon-text">
                                <h3><?php echo $getTelehealth['how_it_works_icon_1_title']; ?></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-12 col-12">
                        <div class="wrk-div-box">
                            <div class="wrk-icon">
                                <?php if($getTelehealth['how_it_works_icon_2_image'] != null): ?>
                                <img src="<?php echo e(Storage::url($getTelehealth['how_it_works_icon_2_image'])); ?>" alt="<?php echo e($getTelehealth['how_it_works_icon_2_title']); ?>">
                                <?php else: ?>
                                <img src="<?php echo e(asset('frontend_assets/images/w-2.png')); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="wrk-icon-text">
                                <h3><?php echo $getTelehealth['how_it_works_icon_2_title']; ?></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-12 col-12">
                        <div class="wrk-div-box">
                            <div class="wrk-icon">
                                <?php if($getTelehealth['how_it_works_icon_3_image'] != null): ?>
                                <img src="<?php echo e(Storage::url($getTelehealth['how_it_works_icon_3_image'])); ?>" alt="<?php echo e($getTelehealth['how_it_works_icon_3_title']); ?>">
                                <?php else: ?>
                                <img src="<?php echo e(asset('frontend_assets/images/w-3.png')); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="wrk-icon-text">
                                <h3><?php echo $getTelehealth['how_it_works_icon_3_title']; ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="blog-sec">
    <div class="container">
        <div class="blog-box-wrap">
            <div class="blog_slider">
                <?php if($blogs->count() > 0): ?>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="blog_padding">
                    <div class="blog-box-img">
                        <a href="<?php echo e(route('blogs.details', ['category_slug' => $item['category']['slug'], 'blog_slug' => $item['slug']])); ?>">
                            <img src="<?php echo e(Storage::url($item['image'])); ?>" alt="" /></a>
                    </div>
                    <div class="blog-rit d-flex" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="600">
                        <div class="bl-text bl-text-1">
                            <a href="<?php echo e(route('blogs.details', ['category_slug' => $item['category']['slug'], 'blog_slug' => $item['slug']])); ?>">
                                <h3><?php echo e($item['title']); ?></h3>
                            </a>
                            <div class="date-box d-flex align-items-center">
                                <div class="bl-date-img">
                                    <img src="<?php echo e(asset('frontend_assets/images/date.png')); ?>" alt="" />
                                </div>
                                <div class="bl-date">
                                    <h4><?php echo e(date("d M' Y", strtotime($item['created_at']))); ?></h4>
                                </div>
                            </div>
                            <p>
                                <?php echo substr($item['content'], 0, 200); ?>...
                            </p>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- <div class="col-xl-6 col-md-12 col-12">
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="blog-rit d-flex" data-aos="fade-up" data-aos-easing="linear"
                                    data-aos-duration="600">
                                    <div class="bl-lft">
                                        <a
                                            href="<?php echo e(route('blogs.details', ['category_slug' => $item['category']['slug'], 'blog_slug' => $item['slug']])); ?>"><img
                                                src="<?php echo e(Storage::url($item['image'])); ?>" alt="" /></a>
                                    </div>
                                    <div class="bl-text">
                                        <a
                                            href="<?php echo e(route('blogs.details', ['category_slug' => $item['category']['slug'], 'blog_slug' => $item['slug']])); ?>">
                                            <h3><?php echo e($item['title']); ?></h3>
                                        </a>
                                        <div class="date-box d-flex align-items-center pt-3">
                                            <div class="bl-date-img">
                                                <img src="<?php echo e(asset('frontend_assets/images/date.png')); ?>"
                                                    alt="" />
                                            </div>
                                            <div class="bl-date">
                                                <h4><?php echo e(date("d M' Y", strtotime($item['created_at']))); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div> -->
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/telehealth.blade.php ENDPATH**/ ?>