<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="MD Global  - Admin Panel">
    <meta name="keywords" content="Admin">
    <meta name="author" content="Excellis IT">
    <meta name="robots" content="noindex, nofollow">
    <title>Login - <?php echo e(env('APP_NAME')); ?> Panel</title>
    <?php
        use App\Helpers\Helper;
    ?>
    <?php if(Helper::getFavicon() != null): ?>
        <link rel="shortcut icon" type="image/png" href="<?php echo e(Storage::url(Helper::getFavicon())); ?>" />
    <?php else: ?>
        <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('admin_assets/img/favicon.ico')); ?>">
    <?php endif; ?>

    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/plugins/fontawesome/css/all.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/line-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/material.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/font-awesome.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/line-awesome.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/font-awesome.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>

<body class="account-page">
    <div class="main-wrapper">
        <div class="account-content">
            <div class="container">

                <div class="account-logo">
                    <?php if(Helper::getLogo() != null): ?>
                        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(Storage::url(Helper::getLogo())); ?>" /></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('admin_assets/img/logo2.png')); ?>" /></a>
                    <?php endif; ?>
                </div>

                <div class="account-box">
                    <div class="account-wrapper">
                        <h3 class="account-title">Login</h3>
                        <p class="account-subtitle">Access to our dashboard</p>

                        <form action="<?php echo e(route('admin.login.check')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" class="form-control" name="email" id="inputEmailAddress"
                                    placeholder="Email Address">
                                <?php if($errors->has('email')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col">
                                        <label>Password</label>
                                    </div>
                                    
                                </div>
                                <div class="position-relative" id="show_hide_password">
                                    <input type="password" class="form-control border-end-0" name="password"
                                        id="inputChoosePassword" placeholder="Enter Password">
                                    <a href="javascript:;" class=""><span class="fa fa-eye-slash"
                                            id="toggle-password"></span></a>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('password')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button class="btn btn-primary account-btn" type="submit">Login</button>
                            </div>
                            <div class="account-footer">
                                <p><a href="<?php echo e(route('admin.forget.password.show')); ?>">Forgot Password?</a></p>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

<script src="<?php echo e(asset('admin_assets/js/jquery-3.6.0.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin_assets/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin_assets/js/layout.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/theme-settings.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/greedynav.js')); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
    <?php if(Session::has('message')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.success("<?php echo e(session('message')); ?>");
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

    <?php if(Session::has('info')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>

    <?php if(Session::has('warning')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>
</script>

<script src="<?php echo e(asset('admin_assets/js/app.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $("#show_hide_password a").on('click', function(event) {
            event.preventDefault();
            if ($('#show_hide_password input').attr("type") == "text") {
                $('#show_hide_password input').attr('type', 'password');
                $('#show_hide_password i').addClass("bx-hide");
                $('#show_hide_password i').removeClass("bx-show");
            } else if ($('#show_hide_password input').attr("type") == "password") {
                $('#show_hide_password input').attr('type', 'text');
                $('#show_hide_password i').removeClass("bx-hide");
                $('#show_hide_password i').addClass("bx-show");
            }
        });
    });
</script>

</html>
<?php /**PATH C:\xampp\htdocs\md_global\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>