<?php
    use App\Helpers\Helper;
?>

<?php if(Request::is('privacy-policy') ||
        Request::is('terms-and-conditions') ||
        Request::is('patient-privacy-policy') ||
        Request::is('patient-terms-and-conditions') ||
        Request::is('doctor-privacy-policy') ||
        Request::is('doctor-terms-and-conditions')): ?>
<?php else: ?>

    <!-- <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <div class="location-div">
            <div class="get-location">
                <a href="javascript:void(0)">
                    <div class="get-location-box d-flex justify-content-between">
                        <div class="get-location-icon">
                            <span><i class="fa-solid fa-location-crosshairs"></i></span>
                        </div>
                        <div class="get-location-text">
                            <button id="find-me" type="button">Get your location</button>
                            <h3>Using GPS</h3>
                        </div>
                    </div>
                </a>
            </div>
            <div class="search_box">
                <div class="search_field">
                    <input type="text" class="input" id="autocomplete1" placeholder="Search your location">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </div>
    </div> -->
    <div class="box_slae" id="box1">
        <div id="deletebtn" onclick="dltFun();"><i class="fas fa-times"></i></div>
        <div class="">
        <div class="location-div">
            <div class="get-location">
                <a href="javascript:void(0)">
                    <div class="get-location-box d-flex align-items-center justify-content-between">
                        <div class="get-location-icon">
                            <span><i class="fa-solid fa-location-crosshairs"></i></span>
                        </div>
                        <div class="get-location-text">
                            <button id="find-me" type="button">Get your location</button>
                            <h3>Using GPS</h3>
                        </div>
                    </div>
                </a>
            </div>
            <div class="search_box">
                <div class="search_field">
                    <input type="text" class="input" id="autocomplete1" placeholder="Search your location">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </div>
        </div>
        <!-- <a class="filter_aplly" href="">Apply</a> -->
    </div>
<?php endif; ?>
<div class="main_manu">
    <div class="main_top">
        <div class="container-fluid">
            <div class="login d-flex align-items-center justify-content-end">
                <span><a href="tel:+1 877 899 3162" class="me-2"><i class="fa-solid fa-phone"></i> +1 877 899 3162 </a></span>
                <span><a href="" class="me-2"><i class="fa-solid fa-envelope"></i> info@mdglobal.org</a></span>
            </div>
        </div>
    </div>

    <div class="add-loc-1 d-block d-md-none">
        <div class="row m-0">
            <div class="col-xxl-12">
                <div id="main">
                    <a href="javascript:void(0)" data-target="#box1" class="btn_all_open">
                        <div class="location d-flex w-100 justify-content-center align-items-center">
                            <div class="location_icon">
                                <i class="fa-solid fa-location-dot"></i>
                            </div>
                            <div class="address_loa">
                                <?php if(Auth::check()): ?>
                                    <?php if(Auth::user()->locations): ?>
                                        <span
                                            id="status"><?php echo e(substr(Auth::user()->locations->address, 0, 50)); ?></span>
                                        <span id="map-link"></span>
                                        <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                    <?php elseif(session()->has('address')): ?>
                                        <span id="status"><?php echo e(substr(session()->get('address'), 0, 50)); ?></span>
                                        <span id="map-link"></span>
                                        <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                    <?php else: ?>
                                        <span id="status">Please Set Your Location</span>
                                        <span id="map-link"></span>
                                        <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                    <?php endif; ?>
                                <?php elseif(Session::has('session_id')): ?>
                                    <span id="status"><?php echo e(substr(session()->get('address'), 0, 50)); ?></span>
                                    <span id="map-link"></span>
                                    <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                <?php else: ?>
                                    <span id="status">Please Set Your Location</span>
                                    <span id="map-link"></span>
                                    <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                <?php endif; ?>

                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="bor_mobile">
        <div class="container-fluid">
            <div class="row justify-content-between align-items-center">
                <div class="col-xl-1 col-lg-3 col-md-3 col-5">
                    <div class="logo <?php echo e(Request::is('patient/*') || Request::is('doctor/*') ? 'logo-d' : ''); ?>">
                        <?php if(Helper::getLogo() != null): ?>
                            <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(Storage::url(Helper::getLogo())); ?>" /></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('frontend_assets/images/logo.png')); ?>" /></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-xxl-4 col-xl-3 col-lg-5 col-md-6 col-6 d-none d-md-block">
                    <div id="main">
                        <a href="javascript:void(0)" data-target="#box1" class="btn_all_open">
                            <div class="location d-flex">
                                <div class="location_icon">
                                    <i class="fa-solid fa-location-dot"></i>
                                </div>
                                <div class="address_loa">
                                    <?php if(Auth::check()): ?>
                                        <?php if(Auth::user()->locations): ?>
                                            <span
                                                id="status"><?php echo e(substr(Auth::user()->locations->address, 0, 50)); ?></span>
                                            <span id="map-link"></span>
                                            <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                        <?php elseif(session()->has('address')): ?>
                                            <span id="status"><?php echo e(substr(session()->get('address'), 0, 50)); ?></span>
                                            <span id="map-link"></span>
                                            <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                        <?php else: ?>
                                            <span id="status">Please Set Your Location</span>
                                            <span id="map-link"></span>
                                            <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                        <?php endif; ?>
                                    <?php elseif(Session::has('session_id')): ?>
                                        <span id="status"><?php echo e(substr(session()->get('address'), 0, 50)); ?></span>
                                        <span id="map-link"></span>
                                        <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                    <?php else: ?>
                                        <span id="status">Please Set Your Location</span>
                                        <span id="map-link"></span>
                                        <span class="arrw-1"><i class="fa-solid fa-angle-down"></i></span>
                                    <?php endif; ?>

                                </div>
                            </div>
                    </div>
                    </a>
                </div>
                <div class="col-xxl-7 col-xl-8 col-lg-4 col-md-3 col-4">
                <header class="header" id="header">
                    <div class="header_toggle"> <i class='bx bx-user' id="header-toggle"></i> </div>
                </header>
                    <div id="cssmenu">
                        <ul>
                            <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="<?php echo e(Request::is('telehealth') ? 'active' : ''); ?>">
                                <?php if(auth()->check()): ?>
                                    <?php if(auth()->user()->hasRole('PATIENT') ||
                                            auth()->user()->hasRole('DOCTOR')): ?>
                                        <a href="<?php echo e(route('telehealth')); ?>">Telehealth</a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="javascript:void(0)" onclick="javascript:openTelehealth()" role="button"
                                        class="btn">Telehealth</a>
                                <?php endif; ?>

                                <!-- <ul>
                                <li><a href="#">Product 1</a>
                                <ul>
                                    <li><a href="#">Sub Product</a></li>
                                    <li><a href="#">Sub Product</a></li>
                                </ul>
                                </li>
                                <li><a href="#">Product 2</a>
                                <ul>
                                    <li><a href="#">Sub Product</a></li>
                                    <li><a href="#">Sub Product</a></li>
                                </ul>
                                </li>
                            </ul> -->
                            </li>
                            <li class="<?php echo e(Request::is('membership-plans') ? 'active' : ''); ?>"><a
                                    href="<?php echo e(route('membership-plans')); ?>">Plans</a></li>
                            
                            
                            <li
                                class="<?php echo e(Request::is('qna-blogs/*') || Request::is('blog-details/*') || Request::is('qna-blogs') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('blogs')); ?>">Q&A /
                                    Blogs</a>
                            </li>
                            <li class="<?php echo e(Request::is('contact-us') ? 'active' : ''); ?>"><a
                                    href="<?php echo e(route('contact-us')); ?>">Contact Us</a></li>

                            <!-- <li><a href="about.html">About us</a></li>
                <li><a href="services.html">Services</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="contact.html">Contact Us</a></li> -->
                            <?php if(Auth::check() && Auth::user()->hasRole('PATIENT')): ?>
                                <li>
                                    <a href="<?php echo e(route('patient.dashboard')); ?>"><span class="u-i"><i
                                                class="fa-regular fa-user"></i></span>Profile</a>
                                </li>
                            <?php elseif(Auth::check() && Auth::user()->hasRole('DOCTOR')): ?>
                                <li>
                                    <a href="<?php echo e(route('doctor.dashboard')); ?>"><span class="u-i"><i
                                                class="fa-regular fa-user"></i></span>Profile</a>
                                </li>
                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e(route('login')); ?>"><span class="u-i"><i
                                                class="fa-regular fa-user"></i></span>Login/Register</a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <div class="mn-btn">
                                    <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#donateModal"><span>donate</span></a>
                                </div>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- offcanvas -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasHeader" aria-labelledby="offcanvasHeaderLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasHeaderLabel">
                <div class="h-logo">
                    <?php if(Helper::getLogo() != null): ?>
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(Storage::url(Helper::getLogo())); ?>" /></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('frontend_assets/images/logo.png')); ?>" /></a>
                <?php endif; ?>
                </div>
            </h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                aria-label="Close"></button>
        </div>
        <div class="offcanvas-body t-body">
            <div class="d-lg-block d-none">
                At MD Global, we provide qualified immigrant investors a secured platform to invest in a variety of
                high-yielding and long-term projects that primarily include healthcare-related investments. We also
                invest
                in projects that include new construction, rehabilitation, or adaptive reuse in a variety of industries
                including retail, food service, accommodation service, multifamily, assisted living, skilled nursing,
                medical offices, hospitals, construction, and professional offices.
            </div>
            <p class="d-flex align-items-center mt-3">
                <i class="text-yellow fs-5 fa-solid fa-location-dot"></i>
                <a target="_blank" class=" ms-2 text-decoration-none text-secondary" href="#">17581 Sultana St,
                    Hesperia, CA 92345, USA</a>
            </p>
            <p class="d-flex align-items-center">
                <i class="text-yellow fs-5 fa-solid fa-envelope"></i>
                <a class=" ms-2 text-decoration-none text-secondary" href="mailto:info@mdglobal.org">
                    info@mdglobal.org
                </a>
            </p>
            <p class="d-flex align-items-center">
                <i class="text-yellow fs-5 fa-solid fa-phone"></i>
                <span>
                    <a class=" ms-2 text-decoration-none text-secondary" href="tel:7608811141">
                        760-881-1141
                    </a><br>
                </span>
            </p>
            <p class="d-flex align-items-center">
                <i class="text-yellow fs-5 fa-solid fa-fax"></i>
                <a target="_blank" class=" ms-2 text-decoration-none text-secondary" href="fax:7604862571">
                    760-486-2571
                </a>
            </p>
            <h4 class="mt-3">Follow Us On</h4>
            <div class="d-flex align-items-center">
                <a class="text-secondary mx-2 fs-5" href="#" target="_blank"><i
                        class="fa-brands fa-linkedin"></i></a>
                <a class="text-secondary mx-2 fs-5" href="#" target="_blank"><i
                        class="fa-brands fa-facebook-f"></i></a>
                <a class="text-secondary mx-2 fs-5" href="#" target="_blank"><i
                        class="fa-brands fa-twitter"></i></a>
                <a class="text-secondary mx-2 fs-5" href="#" target="_blank"><i
                        class="fa-brands fa-instagram"></i></a>
                <a class="text-secondary mx-2 fs-5" href="#" target="_blank"><i
                        class="fa-brands fa-youtube"></i></a>
            </div>
        </div>
    </div>

    <!-- Modal -->
<?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>