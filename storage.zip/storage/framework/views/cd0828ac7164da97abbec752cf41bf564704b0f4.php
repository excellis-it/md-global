<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Patient Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        use App\Helpers\Helper;
    ?>
    <section class="sidebar-sec" id="body-pd">
        <div class="container-fluid">
            <div class="sidebar-wrap d-flex justify-content-between">

                <?php echo $__env->make('frontend.patient.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Content -->
                <div class="sidebar-right height-100">
                    <div class="content">
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="profile-div d-flex align-items-center">
                                    <div class="profile-img">
                                        <?php if(Auth::user()->profile_picture): ?>
                                            <img src="<?php echo e(Storage::url(Auth::user()->profile_picture)); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend_assets/images/profile.png')); ?>" alt="">
                                        <?php endif; ?>
                                    </div>
                                    <div class="profile-text">
                                        <h2><span>Hello!</span><?php echo e(Auth::user()->name); ?></h2>
                                        <a href="mailto:<?php echo e(Auth::user()->email); ?>"><?php echo e(Auth::user()->email); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="my-app-div-wrap">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">My Appointment</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Medical Stuff Suggestion for you</button>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <div class="my-app-div">
                                        <?php if($upcominAppontment): ?>
                                            <div class="my-app-head-wrap d-flex justify-content-between align-items-center">
                                                <div class="my-app-head">
                                                    <h3>My Appointment</h3>
                                                </div>
                                                <div class="my-app-head">
                                                    <h4> <?php echo e(Helper::getLeftTimeFromDate($upcominAppontment['appointment_date'], $upcominAppontment['appointment_time'])); ?>

                                                        left</h4>
                                                </div>
                                            </div>
                                            <hr />
                                            <div class="row">
                                                <div class="col-xl-12 col-12">
                                                    <div class="profile-div profile-div-2 d-flex">
                                                        <div class="profile-img">
                                                            <img src="<?php echo e(asset('frontend_assets/images/profile.png')); ?>"
                                                                alt="">
                                                        </div>
                                                        <div class="profile-text">
                                                            <h2><?php echo e($upcominAppontment['doctor']['name']); ?></h2>
                                                            <p> <?php echo e(Helper::getDoctorSpecializations($upcominAppontment['doctor']['id'])); ?>

                                                            </p>
                                                            <p><?php echo e($upcominAppontment['doctor']['year_of_experience']); ?>

                                                                years experience</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-xl-6 col-12">
                                                        <div class="app-time-wrap d-flex  align-items-center">
                                                            <div class="app-time-img">
                                                                <span><i class="fa-regular fa-clock"></i></span>
                                                            </div>
                                                            <div class="app-time me-3">
                                                                <h3> Appointment time</h3>
                                                                <p><?php echo e(date('D, d M Y', strtotime($upcominAppontment['appointment_date']))); ?>

                                                                    <?php echo e($upcominAppontment['appointment_time']); ?></span></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-xl-6 col-12">
                                                        <div class="app-time-wrap d-flex align-items-center">
                                                            <div class="app-time-img">
                                                                <span><i
                                                                        class="fa-solid fa-house-chimney-medical"></i></span>
                                                            </div>
                                                            <div class="app-time app-time-1">
                                                                <h3>Clinic Details</h3>
                                                                <p><?php echo e($upcominAppontment['clinic_name']); ?>

                                                                    <span><?php echo e($upcominAppontment['clinic_address']); ?></span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="my-app-head-wrap d-flex justify-content-between align-items-center">
                                                <div class="my-app-head">
                                                    <h3>My Appointment</h3>
                                                </div>
                                                <div class="my-app-head">
                                                    <h4> No Appointment</h4>
                                                </div>
                                            </div>
                                            <hr />
                                            <div class="row">
                                                <div class="col-xl-12">
                                                    
                                                    <div class="my_app_img">
                                                        <img src="<?php echo e(asset('frontend_assets/images/my_appoinment.jpg')); ?>" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                    <div class="my-app-div justify-content-between align-items-center">
                                        <div class="my-app-head-wrap d-flex justify-content-between align-items-center">
                                            <div class="my-app-head">
                                                <h3>Medical Stuff<span>Suggestion for you</span></h3>
                                            </div>
                                        </div>
                                        <hr />
                                        <div class="dr-suggestio-wrap srl" id="srl_1">
                                            <?php if(count($doctors) > 0): ?>
                                                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="dr-suggestion">
                                                        <div class="row">
                                                            <div class="col-xl-4 col-md-6 col-12">
                                                                <div class="dr-name d-flex align-items-center">
                                                                    <div class="dr-name-img">
                                                                        <?php if($doctor->profile_picture): ?>
                                                                            <img src="<?php echo e(Storage::url($doctor->profile_picture)); ?>"
                                                                                alt="">
                                                                        <?php else: ?>
                                                                            <img src="<?php echo e(asset('frontend_assets/images/profile.png')); ?>"
                                                                                alt="">
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="dr-name-text">
                                                                        <h2><?php echo e($doctor->name); ?></h2>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-4 col-md-6 col-12">
                                                                <div class="app-time app-time-2">
                                                                    <h3><i class="fa-solid fa fa-medkit"></i>
                                                                        Specializations</h3>
                                                                    <p><?php echo e(Helper::getDoctorSpecializations($doctor->id)); ?>

                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-4 col-md-6 col-12">
                                                                <div class="app-time app-time-1">
                                                                    <h3><i class="fa-solid fa fa-history"></i>
                                                                        Year of Experience</h3>
                                                                    <p><?php echo e($doctor->year_of_experience); ?> Years</p>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <div class="dr-suggestion">
                                                    <div class="row">
                                                        <div class="col-xl-12">
                                                            
                                                            <center><img
                                                                    src="<?php echo e(asset('frontend_assets/images/no-data-found-removebg-preview.png')); ?>"
                                                                    alt=""></center>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/patient/dashboard.blade.php ENDPATH**/ ?>