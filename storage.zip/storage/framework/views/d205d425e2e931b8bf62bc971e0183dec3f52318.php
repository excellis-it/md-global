<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul class="sidebar-vertical">
                <li class="menu-title">
                    <span>Main</span>
                </li>
                <li class="<?php echo e(Request::is('admin/dashboard*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>"><i class="la la-dashboard"></i> <span>Dashboard</span></a>
                </li>

                <li class="submenu">
                    <a href="#"
                        class="<?php echo e(Request::is('admin/profile*') || Request::is('admin/password*') || Request::is('admin/detail*') ? 'active' : ' '); ?>"><i
                            class="la la-user-cog"></i> <span>Manage Account </span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li class="<?php echo e(Request::is('admin/profile*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('admin.profile')); ?>">My Profile</a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/password*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('admin.password')); ?>">Change Password</a>
                        </li>
                    </ul>
                </li>
                <li class="menu-title">
                    <span>Speciality Management</span>
                </li>
                <li class="<?php echo e(Request::is('admin/specializations*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('specializations.index')); ?>"><i class="la la-heart"></i>
                        <span>Specialization</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/symptoms*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('symptoms.index')); ?>"><i class="	fa fa-stethoscope"></i>
                        <span>Symptoms</span></a>
                </li>

                <li class="menu-title">
                    <span>User Management</span>
                </li>
                <li class="<?php echo e(Request::is('admin/patients*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('patients.index')); ?>"><i class="fa fa-wheelchair"></i> <span>Manage
                            Patients</span></a>
                </li>

                <li class="<?php echo e(Request::is('admin/medical-stuff*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('medical-stuff.index')); ?>"><i class="fas fa-user-md"></i> <span>Manage
                           Medical Stuff</span></a>
                </li>

                <li class="menu-title">
                    <span>Clinic Management</span>
                </li>
                <li class="<?php echo e(Request::is('admin/clinics*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('clinics.index')); ?>"><i class="fas fa-clinic-medical"></i>
                        <span>Clinics</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/appointments*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('appointments.index')); ?>"><i class="fa fa-calendar"></i>
                        <span>Appointments</span></a>
                </li>

                <li class="menu-title">
                    <span>Plan Section</span>
                </li>
                <li class="<?php echo e(Request::is('admin/plans*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('plans.index')); ?>"><i class="la la-crown"></i> <span>Membership Plans</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/video-call-price*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('video-call-price.index')); ?>"><i class="la la-video"></i> <span>Video Calling Price</span></a>
                </li>
                <li class="menu-title">
                    <span>Transaction</span>
                </li>
                <li class="<?php echo e(Request::is('admin/donations*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('donations.list')); ?>"><i class="la la-hand-holding-usd"></i> <span>Donations</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/membership-history*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('membership-history.index')); ?>"><i class="la la-usd"></i> <span>Membership
                            Transaction</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/video-call-payment*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('video-call-payment.index')); ?>"><i class="la la-cc-stripe"></i> <span>Video Call Payment</span></a>
                </li>
                <li class="menu-title">
                    <span>Others</span>
                </li>
                <li class="submenu">
                    <a href="#" class="<?php echo e(Request::is('admin/blogs*') ? 'active' : ' '); ?>"><i
                            class="la la-blog"></i> <span>Blogs</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li class="<?php echo e(Request::is('admin/blogs/categories*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('blogs.categories.index')); ?>">Category</a>
                        </li>
                        <li
                            class="<?php echo e(Request::is('admin/blogs') || Request::is('admin/blogs/create') || Request::is('admin/blogs/edit/*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('blogs.index')); ?>">Details</a>
                        </li>
                    </ul>
                </li>
                <li class="<?php echo e(Request::is('admin/contact-us*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('contact-us.index')); ?>"><i class="la la-phone"></i> <span>Contact Us</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/help-and-support*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('help-and-support.index')); ?>"><i class="la la-support"></i> <span>Help &
                            Support</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/newsletters*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('newsletters.index')); ?>"><i class="la la-paper-plane"></i>
                        <span>Newsletter</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/notifications*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('notifications.index')); ?>"><i class="la la-bell"></i> <span>Send
                            Notification</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/testimonials*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('testimonials.index')); ?>"><i class="la la-comments"></i> <span>Testimonial</span></a>
                </li>
                <li class="<?php echo e(Request::is('admin/services*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('services.index')); ?>"><i class="la la-tools"></i> <span>Service</span></a>
                </li>
                <li class="submenu">
                    <a href="#" class="<?php echo e(Request::is('admin/cms*') ? 'active' : ' '); ?>"><i
                            class="la la-cog"></i> <span>Settings</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li class="<?php echo e(Request::is('admin/cms/logo*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.logo.index')); ?>">Logo </a>
                        </li>

                        <li class="<?php echo e(Request::is('admin/cms/footer*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.footer.index')); ?>">Footer Content</a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/cms/home') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.home.index')); ?>">Home Page Banners </a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/cms/home-content*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.home-content.index')); ?>">Home Page Content </a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/cms/telehealth*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.telehealth.index')); ?>">Telehealth Page Content </a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/cms/qna*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.qna.index')); ?>">QNA Page</a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/cms/contact-us*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.contact-us.index')); ?>">Contact Us Page</a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/cms/terms-and-condition*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.terms-and-condition.index')); ?>">Terms & Condition Page</a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/cms/privacy-policy*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.privacy-policy.index')); ?>">Privacy Policy Page</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\md_global\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>