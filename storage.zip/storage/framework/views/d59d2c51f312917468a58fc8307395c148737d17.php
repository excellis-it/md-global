
<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Register
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
    use App\Helpers\Helper;
?>
<div class="login_sec_wrap">
    <div class="container-fluid login_container_fluid">
      <div class="row justify-content-end m-0">
        <div class="col-xl-6 col-lg-12 col-12 p-0">
          <div class="login_sec_left">
            <div class="login_sec_left_bg"></div>
            <div class="width_545">
              <div class="main_hh">
                <div class="login_sec_right_text">
                  <div class="login-logo">
                    <?php if(Helper::getLogo() != null): ?>
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(Storage::url(Helper::getLogo())); ?>" /></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('frontend_assets/images/logo.png')); ?>" /></a>
                <?php endif; ?>

                  </div>
                  <div class="res-head pb-5">
                    <h1>
                      Let’s get started! Register your name <br />
                      and other information
                    </h1>
                  </div>
                </div>
                <div class="login_form login_form-1">
                  <form action="<?php echo e(route('register.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-xl-6 col-12 col-12">
                        <div class="form-group">
                          <label for="exampleInputEmail1" class="form-label">First Name</label>
                          <input type="text" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" name="first_name" value="<?php echo e(old('first_name')); ?>" />
                            <?php if($errors->has('first_name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                            <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-xl-6 col-12 col-12">
                        <div class="form-group">
                          <label for="exampleInputEmail1" class="form-label">Last Name</label>
                          <input type="text" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" name="last_name" value="<?php echo e(old('last_name')); ?>" />
                            <?php if($errors->has('last_name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                            <?php endif; ?>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xl-6 col-12 col-12">
                        <div class="form-group">
                          <label for="exampleInputEmail1" class="form-label">Email</label>
                          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(old('email')); ?>"
                            aria-describedby="emailHelp" name="email" />
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-xl-6 col-12 col-12">
                        <div class="form-group">
                          <label for="exampleInputEmail1" class="form-label">Phone Number</label>
                          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(old('phone')); ?>"
                            aria-describedby="emailHelp" name="phone"/>
                            <?php if($errors->has('phone')): ?>
                                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                            <?php endif; ?>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xl-6 col-12 col-12">
                        <div class="form-group g-h">
                          <label for="exampleInputEmail1" class="form-label">Gender</label><select class="form-select"
                            aria-label="Default select example" name="gender">
                            <option selected value="">Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                          </select>
                          <?php if($errors->has('gender')): ?>
                          <div class="error" style="color:red;">
                              <?php echo e($errors->first('gender')); ?></div>
                      <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-xl-6 col-12 col-12">
                        <div class="form-group">
                          <label for="exampleInputEmail1" class="form-label">Age</label>
                          <input type="date" class="form-control" id="exampleInputEmail1" name="age" value="<?php echo e(old('age')); ?>"
                            aria-describedby="emailHelp" />
                            <?php if($errors->has('age')): ?>
                            <div class="error" style="color:red;">
                                <?php echo e($errors->first('age')); ?></div>
                        <?php endif; ?>
                        </div>
                      </div>
                    </div>
                    
                    <div class="row">
                      <div class="col-xl-6 col-12 col-12">
                        <div class="form-group">
                          <label for="txtPassword">Password</label>
                          <div class="i-btn position-relative">
                              <input type="password" id="password-field" class="form-control" name="password" value="<?php echo e(old('password')); ?>"/>
                              <button type="button" id="btnToggle" class="toggle">
                               <i id="eyeIcon" class="fa fa-eye-slash" toggle="#password-field"></i>
                                </button>
                          </div>
                          <?php if($errors->has('password')): ?>
                            <div class="error" style="color:red;">
                                <?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-xl-6 col-12 col-12">
                        <div class="form-group">
                          <label for="txtPassword">Confirm Password</label>
                          <div class="position-relative">
                            <input type="password" id="password-field1" class="form-control" name="confirm_password" value="<?php echo e(old('confirm_password')); ?>"/>
                            <button type="button" id="btnToggle" class="toggle">
                            <i id="eyeIcon1" class="fa fa-eye-slash" toggle="#password-field1"></i>
                            </button>
                          </div>
                            <?php if($errors->has('confirm_password')): ?>
                                <div class="error" style="color:red;">
                                    <?php echo e($errors->first('confirm_password')); ?></div>
                            <?php endif; ?>
                        </div>
                      </div>
                    </div>
                    <button class="btn btn-lg btn-primary btn-block btn-login">
                      Register
                    </button>
                    <div class="login-text login-text-2 text-center">
                      <p>
                        Don’t Have an Account? <a href="<?php echo e(route('login')); ?>">Login</a>
                      </p>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  $("#eyeIcon1").click(function() {
      // alert('d')
      $(this).toggleClass("fa-eye fa-eye-slash");
      var input = $($(this).attr("toggle"));
      if (input.attr("type") == "password") {
          input.attr("type", "text");
      } else {
          input.attr("type", "password");
      }
  });
</script>
<script>
  $("#eyeIcon").click(function() {
      // alert('d')
      $(this).toggleClass("fa-eye fa-eye-slash");
      var input = $($(this).attr("toggle"));
      if (input.attr("type") == "password") {
          input.attr("type", "text");
      } else {
          input.attr("type", "password");
      }
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/auth/register.blade.php ENDPATH**/ ?>