
<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Mange Clinic Address
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        use App\Helpers\Helper;
    ?>
    <section class="sidebar-sec" id="body-pd">
        <div class="container-fluid">
            <div class="sidebar-wrap d-flex justify-content-between">
                <?php echo $__env->make('frontend.doctor.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Content -->
                <div class="sidebar-right height-100">
                    <div class="content">
                        <div class="my-app-div-wrap">
                            <div class="content-head-wrap d-flex justify-content-between align-items-center">
                                <div class="content-head mb-4">
                                    <h2>Manage Clinic Address</h2>
                                    <h3><a href="<?php echo e(route('doctor.dashboard')); ?>">Dashboard</a> / Manage Clinic Address</h3>
                                </div>
                                <div class="add-address">
                                    <a href="<?php echo e(route('doctor.manage-clinic.create')); ?>"><span>+ Add Address</span></a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="clinical-consultation-wrap">
                                        <!-- <div class="clinicl-head">
                                                    <h3>Clinical Consultation</h3>
                                                </div> -->
                                        <?php if($clinics->count() > 0): ?>
                                            <div class="clinical-box-wrap">
                                                <?php $__currentLoopData = $clinics->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="row">
                                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="col-xl-10 col-lg-9 col-12">
                                                                <div class="manage-clinic-div">
                                                                    <div class="row">
                                                                        <div class="col-xl-3 col-md-6 col-12">
                                                                            <div class="cl-name">
                                                                                <h3>Clinic Name</h3>
                                                                                <h2><?php echo e($clinic['clinic_name']); ?></h2>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-xl-3 col-md-6 col-12">
                                                                            <div class="cl-name">
                                                                                <h3>Phone Number</h3>
                                                                                <h2><?php echo e($clinic['clinic_phone']); ?></h2>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-xl-3 col-md-6 col-12">
                                                                            <div class="cl-name">
                                                                                <h3>Clinic Address</h3>
                                                                                <h2><?php echo e($clinic['clinic_address']); ?></h2>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-xl-3 col-md-6 col-12">
                                                                            <div class="cl-name">
                                                                                <h3>Slot Day</h3>
                                                                                <h2>
                                                                                    <?php echo e(Helper::getClinicOpeninDay($clinic['id'])); ?>

                                                                                </h2>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-2 col-lg-3 col-12">
                                                                <div class="cl-edit">
                                                                    <div class="edit-btn d-flex align-items-center">
                                                                        <div class="edit-btn-1">
                                                                            <a
                                                                                href="<?php echo e(route('doctor.manage-clinic.edit', $clinic['id'])); ?>"><span><i
                                                                                        class="fa-solid fa-pen-to-square"></i></span></a>
                                                                        </div>
                                                                        <div class="edit-btn-1 edit-btn-2">
                                                                            <a href="javascript:void(0);" id="delete"
                                                                                data-route="<?php echo e(route('doctor.manage-clinic.delete', $clinic['id'])); ?>"><span><i
                                                                                        class="fa-solid fa-trash-can"></i></span></a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <div class="pagi_1 justify-content-center">
                                                    <nav aria-label="Page navigation example">
                                                        <div class="">
                                                            <?php echo e($clinics->links()); ?>

                                                        </div>
                                                    </nav>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="clinical-box-wrap">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="no-data-found-img text-center">
                                                            <img src="<?php echo e(asset('frontend_assets/images/no-search-found.webp')); ?>"
                                                                alt="No Data Found">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).on('click', '#delete', function(e) {
            swal({
                    title: "Are you sure?",
                    text: "To delete the clinic address.",
                    type: "warning",
                    confirmButtonText: "Yes",
                    showCancelButton: true
                })
                .then((result) => {
                    if (result.value) {
                        window.location = $(this).data('route');
                    } else if (result.dismiss === 'cancel') {
                        swal(
                            'Cancelled',
                            'Your stay here :)',
                            'error'
                        )
                    }
                })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/doctor/manage-clinic-address/list.blade.php ENDPATH**/ ?>