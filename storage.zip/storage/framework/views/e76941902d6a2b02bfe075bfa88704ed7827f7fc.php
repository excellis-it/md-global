<?php if(isset($chat_call)): ?>
    <div class="dr-chat-request-box">
        <div class="dr-cam-img">
            <a href="javascript:void(0);" id="zoom-video-<?php echo e($reciver->id); ?>" data-id="<?php echo e($reciver->id); ?>"
                class="video-call-active">
                <div class="cam-img">
                    <span><i class="fa-solid fa-video"></i></span>
                </div>
            </a>
        </div>
        <div class="profile-text">
            <div id="<?php echo e($reciver->id); ?>-status" class="dr-chat-request-img">
                <?php if($reciver->profile_picture): ?>
                    <img src="<?php echo e(Storage::url($reciver->profile_picture)); ?>" alt="">
                <?php else: ?>
                    <img src="<?php echo e(asset('frontend_assets/images/profile.png')); ?>" alt="">
                <?php endif; ?>
            </div>
            <div class="dr-chat-request-name">
                <h2><?php echo e($reciver->name); ?></h2>
            </div>

        </div>

        <div class="chat-sec-box chat-srl_1" id="chat-container">
            <?php if($chats->count() > 0): ?>
                <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($chat->sender_id == Auth::user()->id): ?>
                        <div class="chat-sec-left chat-sec-right pb-1">
                            <div class="chat-sec-left-wrap d-flex justify-content-end">
                                <div class="chat-sec-left-text-box">
                                    <div class="chat-sec-left-text">
                                        <p>
                                            <?php echo e($chat->message); ?>

                                        </p>
                                    </div>
                                    <div class="tm-div d-block pt-2 text-end">
                                        <h4>
                                            <?php echo e(date('h:i A', strtotime($chat->created_at))); ?>

                                        </h4>
                                    </div>
                                </div>

                            </div>
                        </div>
                    <?php else: ?>
                        <div class="chat-sec-left pb-1">
                            <div class="chat-sec-left-wrap d-flex">

                                <div class="chat-sec-left-text-box">
                                    <div class="chat-sec-left-text">
                                        <p>
                                            <?php echo e($chat->message); ?>

                                        </p>
                                    </div>
                                    <div class="tm-div d-block pt-2">
                                        <h4>
                                            <?php echo e(date('h:i A', strtotime($chat->created_at))); ?>

                                        </h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                
                <div class="chat-not-available">
                    <h4 class="text-center">No Chat Yet ... </h4>
                    <p class="text-center">
                        Start Chatting with your patient now.
                    </p>
                </div>
            <?php endif; ?>

        </div>
        <div class="chat_form-div">
            <form action="javascript:void(0);" id="chat-form">
                <input type="hidden" class="reciver_id" value="<?php echo e($reciver->id); ?>">
                <div class="type-sec d-flex justify-content-center align-items-center">
                    <div class="type-div">
                        <div class="form-group">
                            <input type="text" class="form-control" id="user-chat" value=""
                                placeholder="Type here..." required="">
                        </div>
                    </div>
                    <div class="send-div">
                        <button type="submit" value="Submit"><img src="<?php echo e(asset('frontend_assets/images/send.png')); ?>"
                                alt=""></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    </div>
<?php endif; ?>

<script src="https://cdn.socket.io/4.0.1/socket.io.min.js"></script>

<?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/doctor/chat/chat-body.blade.php ENDPATH**/ ?>