
<?php $__env->startSection('title'); ?>
Website Logo Upload  - <?php echo e(env('APP_NAME')); ?> admin
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <style>
        .dataTables_filter {
            margin-bottom: 10px !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section id="loading">
        <div id="loading-content"></div>
    </section>
    <div class="page-wrapper">

        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Website Logo Upload</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">CMS</li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('cms.logo.index')); ?>">Logo Upload</a></li>
                        </ul>
                    </div>
                    <div class="col-auto float-end ms-auto">
                        
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <div class="row">
                            <div class="col-xl-12 mx-auto">
                                <h6 class="mb-0 text-uppercase">Website Logo Upload</h6>
                                <hr>
                                <div class="card border-0 border-4">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('cms.logo.update')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($logo->id  ?? ''); ?>">
                                            <div class="border p-4 rounded">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Logo
                                                            <span style="color: red;">*</span></label>
                                                        <input type="file" name="logo" id=""
                                                            class="form-control" value="<?php echo e($logo['logo'] ?? ''); ?>">
                                                        <?php if($errors->has('logo')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('logo')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label">
                                                            <span style="color: red;">*</span></label>
                                                        <?php if(isset($logo) && $logo['logo'] != null): ?>
                                                            <img src="<?php echo e(Storage::url($logo['logo'])); ?>"
                                                                alt="logo" style="width: 100px; height: 100px;">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('admin_assets/img/logo2.png')); ?>"
                                                                alt="logo" style="width: 100px; height: 100px;">
                                                        <?php endif; ?>

                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Favicon
                                                            <span style="color: red;">*</span></label>
                                                        <input type="file" name="favicon" id=""
                                                            class="form-control" value="<?php echo e($logo['favicon'] ?? ''); ?>">
                                                        <?php if($errors->has('favicon')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('favicon')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label">
                                                            <span style="color: red;">*</span></label>
                                                        <?php if(isset($logo) && $logo['favicon'] != null): ?>
                                                            <img src="<?php echo e(Storage::url($logo['favicon'])); ?>"
                                                                alt="favicon" style="width: 100px; height: 100px;">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('admin_assets/img/favicon.ico')); ?>"
                                                                alt="favicon" style="width: 100px; height: 100px;">
                                                        <?php endif; ?>

                                                    </div>

                                                    <div class="row" style="margin-top: 20px; float: left;">
                                                        <div class="col-sm-9">
                                                            <button type="submit"
                                                                class="btn px-5 submit-btn">Update</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/admin/cms/logo/update.blade.php ENDPATH**/ ?>