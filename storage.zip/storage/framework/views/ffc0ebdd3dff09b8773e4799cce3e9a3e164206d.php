<?php $__env->startSection('meta_title'); ?>
<meta name="keywords" content="<?php echo e($homeContents['meta_keyword'] ?? ''); ?>">
<meta name="description" content="<?php echo e($homeContents['meta_description'] ?? ''); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e($homeContents['meta_title'] ?? ''); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<style>
    .top-title h1,h2,h3,p{
        color: black !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="banner__slider banner_sec">
    <div class="slider stick-dots">
        
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="slide">
            <div class="slide__img">
                <img src="<?php echo e($banner->image); ?>" alt="" data-lazy="" class="full-image" />
            </div>
            <div class="slide__content slide__content__left">
                <div class="slide__content--headings text-left" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="1000">
                    <h1 class="title">
                        <?php echo $banner->title; ?>

                    </h1>
                    <p class="top-title">
                        <?php echo $banner->sub_title; ?>

                        
                    </p>
                </div>
                <!-- <div class="main-btn pt-4">
                                    <?php if(!Auth::check()): ?>
    <a href="<?php echo e(route('login')); ?>"><span>get started</span><span class="btn-arw"><i
                                                    class="fa-solid fa-arrow-right"></i></span></a>
    <?php endif; ?>
                                </div> -->
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<section class="after_banner">
    <div class="container">

        <div class="row justify-content-center m-0">
            <div class="col-xl-4 col-md-6 col-12 p-0">
                <a href="<?php echo e(isset($homeContents['colab_section_1_link']) && $homeContents['colab_section_1_link'] ? $homeContents['colab_section_1_link'] : 'https://www.youtube.com/embed/RMwow6cw6HM'); ?>" target="_blank">
                    <div class="white_box">
                        <span><i class="fa-solid fa-headset"></i></span>
                        
                        <h4><?php echo $homeContents['colab_section_1_title'] ?? ''; ?></h4>
                        <p> <?php echo $homeContents['colab_section_1_description'] ?? ''; ?></p>
                    </div>
                </a>
            </div>
            <div class="col-xl-4 col-md-6 col-12 p-0">
                <a href="<?php echo e(isset($homeContents['colab_section_2_link']) && $homeContents['colab_section_2_link'] ? $homeContents['colab_section_2_link'] : 'https://youtu.be/xn6FtTZYeWE'); ?>" target="_blank">
                    <div class="white_box bg_blue">
                        <span><i class="fa-regular fa-handshake"></i></span>
                        
                        <h4><?php echo $homeContents['colab_section_2_title'] ?? ''; ?></h4>
                        <p> <?php echo $homeContents['colab_section_2_description'] ?? ''; ?></p>
                    </div>
                </a>
            </div>
            <div class="col-xl-4 col-md-6 col-12 p-0">
                <a href="<?php echo e(isset($homeContents['colab_section_3_link']) && $homeContents['colab_section_3_link'] ? $homeContents['colab_section_3_link'] : 'https://ioe.hsabank.com/home'); ?>" target="_blank">
                    <div class="white_box">
                        <span><i class="fa-solid fa-heart-pulse"></i></span>
                        
                        <h4><?php echo $homeContents['colab_section_3_title'] ?? ''; ?></h4>
                        <p> <?php echo $homeContents['colab_section_3_description'] ?? ''; ?></p>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>


<section class="abt-sec">
    <div class="container">
        <div class="abt-sec-wrap">
            <div class="row justify-content-between">
                <div class="col-xl-5 col-md-6 col-12">
                    <div class="abt-vdo">
                        <div class="">
                            <iframe width="100%" height="315" src="<?php echo e(isset($homeContents['about_section_link']) && $homeContents['about_section_link'] ? $homeContents['about_section_link'] : 'https://www.youtube.com/embed/tE0iX5Z6Aek'); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen=""></iframe>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-md-6 col-12">
                    <div class="abt-text pb-3">
                        <div class="head-1 h-b">
                            
                            <h2><?php echo $homeContents['about_section_title'] ?? ''; ?></h2>
                        </div>
                        <div class="para p-b">
                            
                            <p>
                                <?php echo $homeContents['about_section_description'] ?? ''; ?>

                            </p>
                        </div>
                        <div class="main-btn pt-4">
                            <a href="" tabindex="0"><span>read more</span><span class="btn-arw"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="service" style="background: url(<?php echo e(asset('frontend_assets/images/bg_dots.png')); ?>);">
    <div class="container">
        <div class="service-wrap">
            <div class="service-head text-center" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="1000">
                <div class="head-1 h-b">
                    
                    <h2><?php echo $homeContents['services_section_title'] ?? ''; ?></h2>
                </div>
            </div>
            <div class="serv-wrap">
                <div class="services_slid">
                    <?php if($service->count() > 0): ?>
                    <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="services_padding">

                        <div class="serv-box" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="300">
                            <div class="services_img">
                                
                                <img src="<?php echo e(Storage::url($data['image'])); ?>" alt="" />
                            </div>
                            <div class="serv-text">
                                <div class="serv-head">
                                    
                                    <h3><?php echo e($data['title'] ?? ''); ?></h3>
                                </div>
                                <div class="serv-p">
                                    <div class="para">
                                        
                                        <p><?php echo $data['description'] ?? ''; ?></p>
                                    </div>
                                </div>
                            </div>
                            
                        <div class="main-btn-2">
                            <a href="<?php echo e(route('service.details',['service_slug' => $data->slug])); ?>">READ MORE<span class="btn-dash"><i class="fa-solid fa-minus"></i></span><span class="btn-dot"><i class="fa-solid fa-ellipsis"></i></span></a>
                        </div>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
    
    </div>
    </div>
    <div class="main-btn text-center pt-4">
        <a href="<?php echo e(route('services')); ?>" tabindex="0"><span>View all</span><span class="btn-arw"><i class="fa-solid fa-arrow-right"></i></span></a>
    </div>
    </div>
    </div>
</section>
<section class="wht-we-do">
    <div class="container">
        <div class="wht-we-do-wrap">
            <div class="row align-items-center g-0">
                <div class="col-xl-6" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="1000">
                    <div class="head-1 h-b">
                        <h2><?php echo $homeContents['section_1_title'] ?? ''; ?></h2>
                    </div>
                    <div class="para p-b">
                        <p>
                            <?php echo $homeContents['section_1_description'] ?? ''; ?>

                        </p>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="white_box_wh">
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/cl-img.png')); ?>" alt="" />
                        </span>
                        <h4>Dermatology</h4>
                        <a href="">Consult Now!</a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="white_box_wh">
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/cl-img.png')); ?>" alt="" />
                        </span>
                        <h4>Orthopedics</h4>
                        <a href="">Consult Now!</a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="white_box_wh">
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/cl-img.png')); ?>" alt="" />
                        </span>
                        <h4>Cardiology</h4>
                        <a href="">Consult Now!</a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="white_box_wh">
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/cl-img.png')); ?>" alt="" />
                        </span>
                        <h4>Gastroenterology</h4>
                        <a href="">Consult Now!</a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="white_box_wh">
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/cl-img.png')); ?>" alt="" />
                        </span>
                        <h4>Pediatrics</h4>
                        <a href="">Consult Now!</a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="white_box_wh">
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/cl-img.png')); ?>" alt="" />
                        </span>
                        <h4>Oncology</h4>
                        <a href="">Consult Now!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- <section class="wht-we-do">
                    <div class="container">
                        <div class="wht-we-do-wrap">
                            <div class="row">
                                <div class="col-xl-3" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="1000">
                                    <div class="head-1 h-b">
                                        <h2><?php echo e($homeContents['section_1_title'] ?? ''); ?></h2>
                                    </div>
                                    <div class="para p-b">
                                        <p>
                                            <?php echo e($homeContents['section_1_description'] ?? ''); ?>

                                        </p>
                                    </div>
                                </div>
                                <div class="col-xl-9 col-lg-12">
                                    <div class="wht-serv">
                                        <?php $__currentLoopData = $homeBodies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homeBody): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="wht-slide">
                                            <div class="wht-slide-wrap" data-aos="fade-up" data-aos-easing="linear"
                                                data-aos-duration="600">
                                                <div class="wht-slide-box">
                                                    <div class="wht-slide-icon-div">
                                                        <div class="wht-slide-icon-1 wht-slide-icon">
                                                            <img src="<?php echo e($homeBody->image); ?>" alt="" />
                                                        </div>

                                                    </div>
                                                    <div class="wht-slide-text">
                                                        <div class="wht-slide-h h-b pb-3">
                                                            <h3>
                                                                <?php echo e($homeBody->title); ?>

                                                            </h3>
                                                        </div>
                                                        <div class="para p-b wht-slide-p">
                                                            <p>
                                                                <?php echo e($homeBody->sub_title); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section> -->
<section class="abt-foremost" style="background: url(<?php echo e(asset('frontend_assets/images/bg_dots.png')); ?>);">
    <div class="container">
        <div class="abt-foremost1">
            <div class="abt-foremost-head text-center" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="1000">
                <div class="head-1 h-b pb-3">
                    
                    <h2><?php echo $homeContents['testimonial_section_title'] ?? ''; ?></h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="test-slider">
                    <div class="test-box-wrap" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="1000">
                        <div class="test-box-1">
                            <div class="test-box">
                                <i class="fa-solid fa-quote-left"></i>
                                <div class="test-name">
                                    
                                    <h4><?php echo $testimonial['name'] ?? ''; ?></h4>
                                </div>
                            </div>
                            <div class="test-p">
                                
                                <p><?php echo $testimonial['description'] ?? ''; ?></p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<section class="blog-sec">
    <div class="container">
        <div class="blog-sec-wrap">
            <div class="blog-sec-head text-center pb-5" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="1000">
                <div class="head-1 h-b pb-3">
                    <h2><?php echo $homeContents['section_2_title'] ?? ''; ?></h2>
                </div>
                <div class="para p-b">
                    <p>
                        <?php echo $homeContents['section_2_description'] ?? ''; ?>

                    </p>
                    
                </div>
            </div>
        </div>
        <div class="blog-box-wrap">
            <div class="blog_slider">
                <?php if($blogs->count() > 0): ?>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="blog_padding">
                    <div class="blog-box-img">
                        <a href="<?php echo e(route('blogs.details', ['category_slug' => $item['category']['slug'], 'blog_slug' => $item['slug']])); ?>">
                            <img src="<?php echo e(Storage::url($item['image'])); ?>" alt="" /></a>
                    </div>
                    <div class="blog-rit d-flex" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="600">
                        <div class="bl-text bl-text-1">
                            <a href="<?php echo e(route('blogs.details', ['category_slug' => $item['category']['slug'], 'blog_slug' => $item['slug']])); ?>">
                                <h3><?php echo e($item['title']); ?></h3>
                            </a>
                            <div class="date-box d-flex align-items-center">
                                <div class="bl-date-img">
                                    <img src="<?php echo e(asset('frontend_assets/images/date.png')); ?>" alt="" />
                                </div>
                                <div class="bl-date">
                                    <h4><?php echo e(date("d M' Y", strtotime($item['created_at']))); ?></h4>
                                </div>
                            </div>
                            <p>
                                <?php echo substr($item['content'], 0, 200); ?>...
                            </p>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- <div class="col-xl-6 col-md-12 col-12">
                                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="blog-rit d-flex" data-aos="fade-up" data-aos-easing="linear"
                                                data-aos-duration="600">
                                                <div class="bl-lft">
                                                    <a
                                                        href="<?php echo e(route('blogs.details', ['category_slug' => $item['category']['slug'], 'blog_slug' => $item['slug']])); ?>"><img
                                                            src="<?php echo e(Storage::url($item['image'])); ?>" alt="" /></a>
                                                </div>
                                                <div class="bl-text">
                                                    <a
                                                        href="<?php echo e(route('blogs.details', ['category_slug' => $item['category']['slug'], 'blog_slug' => $item['slug']])); ?>">
                                                        <h3><?php echo e($item['title']); ?></h3>
                                                    </a>
                                                    <div class="date-box d-flex align-items-center pt-3">
                                                        <div class="bl-date-img">
                                                            <img src="<?php echo e(asset('frontend_assets/images/date.png')); ?>"
                                                                alt="" />
                                                        </div>
                                                        <div class="bl-date">
                                                            <h4><?php echo e(date("d M' Y", strtotime($item['created_at']))); ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div> -->
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\md_global\resources\views/frontend/home.blade.php ENDPATH**/ ?>